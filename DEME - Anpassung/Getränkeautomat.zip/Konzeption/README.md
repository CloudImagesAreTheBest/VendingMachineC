# XML-Dateien

Die sich hier befindenen XML-Dateien sind von draw.io kreirt worden und stellen unsere Diagramme zur Konzeptionierung und Vorgehensweise da.

Sofern ihr diese anschauen wollt, geht auf https://www.draw.io/ und importiert die von hier heruntergeladene beliebige XML-Datei.

// Ich habe diesen Text von VS Code geändert